public interface Phenotype
{
    float Fitness();
}